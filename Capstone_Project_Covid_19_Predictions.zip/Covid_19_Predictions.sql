create database  Covid_19;
use covid_19;
show tables;
select * from covid_19_cleaned_data;

-- 1. Find the number of corona patients who faced shortness of breath

SELECT 
  COUNT(*) AS num_patients
FROM 
  covid_19_cleaned_data
WHERE 
   Shortness_of_breath = 1 AND Corona = 1;


-- 2. Find the number of negative corona patients who have fever and sore_throat

SELECT 
  COUNT(*) AS num_patients
FROM 
  covid_19_cleaned_data
WHERE 
   Fever = 1 and Shortness_of_breath = 1 AND Corona = 0;
    
    
-- 3. Group the data by month and rank the number of positive cases

SELECT 
  MONTH(Test_date) AS month, count(Corona),
  RANK () OVER ( 
		ORDER BY Corona DESC
	)  positive_cases
FROM 
  covid_19_cleaned_data
where Corona = 1
GROUP BY 
    month, Corona
ORDER BY 
    month ASC;


-- 4. Find the female negative corona patients who faced cough and headache

SELECT 
  COUNT(*) AS num_patients
FROM 
  covid_19_cleaned_data
WHERE 
   Cough_symptoms = 1 AND headache = 1 AND Sex = 0 AND Corona = 0;


-- 5. How many elderly corona patients have faced breathing problems
SELECT 
  COUNT(*) AS num_patients
FROM 
  covid_19_cleaned_data
WHERE 
  Age_60_above = 1 AND Shortness_of_breath = 1 AND Corona = 1;


-- 6. Which three symptoms were more common among covid positive patients


SELECT 
  SUM(Cough_symptoms) AS Cough_symptoms_count, 
  SUM(Fever) AS Fever_count, 
  SUM(Sore_throat) AS Sore_throat_count, 
  SUM(Shortness_of_breath) AS Shortness_of_breath_count, 
  SUM(Headache) AS Headache_count
FROM covid_19_cleaned_data
WHERE Corona = 1;

-- 7. Which symptoms were less common among covid positive patients

SELECT 
  SUM(Cough_symptoms = 0) AS Cough_symptoms_count, 
  SUM(Fever = 0) AS Fever_count, 
  SUM(Sore_throat = 0) AS Sore_throat_count, 
  SUM(Shortness_of_breath = 0) AS Shortness_of_breath_count, 
  SUM(Headache = 0) AS Headache_count
FROM covid_19_cleaned_data
WHERE Corona = 1;

-- 8. Which are the most common symptoms  among covid positive males whose known contact was abroad


SELECT 
  SUM(Cough_symptoms) AS Cough_symptoms_count, 
  SUM(Fever) AS Fever_count, 
  SUM(Sore_throat) AS Sore_throat_count, 
  SUM(Shortness_of_breath) AS Shortness_of_breath_count, 
  SUM(Headache) AS Headache_count
FROM covid_19_cleaned_data
WHERE Corona = 1 and Sex = 1 and Known_contact = 0;
